<?php

if(isset($_POST['email_id'])){

    $firstname=$_POST['firstname_id'];
	$lastname=$_POST['lastname_id'];
    $dateofbirth=$_POST['dateofbirth_id'];
    $email3=$_POST['email_id'];
	$message=$_POST['message_id'];
    $phone=$_POST['phone_id'];
    $marital=$_POST['marital_id'];
    $experience=$_POST['experience_id'];
$file=$_FILES['file']['name'];
$file_tmp_name = $_FILES['file']['tmp_name'];
$file_name = $_FILES['file']['name'];
$file_size = $_FILES['file']['size'];
$file_type = $_FILES['file']['type'];
$size=800;

$msg="<html>
				<head>
				<title></title>
				<style type='text/css'>
				body{text-align:center; background:#cccccc; margin:0; padding:0;}
				table{width:700px;}
				.logo{text-align:center; height:100px; border-bottom:3px solid #9a9a9a; font-size:40px; color:#9a9a9a; font-weight:bold;}
				tr{height:80px;}
				.empty{height:80px;}
				.title{font-size:40px; text-align:left; color:#000000; font-weight:bold; width:700px;}
				td{background:#fff; vertical-align:middle;color:#000000 ; font-size:20px; border-bottom:3px solid #9a9a9a;}
				.td1{border-right:3px solid #cccccc;}
				.td3{width:350px; height:80px; color:#6c6d6f; font-size:20px;  vertical-align:middle; text-align:center;  background:#fff ;}
				.noback{background:#9a9a9a;}
				.inf2{color:#503728; background:#fff; border-bottom:3px solid #9a9a9a; font-size:12pt; text-align:left;}
				a{text-decoration:none; color:#9a9a9a;}
				.td2 a{color:#503728;}
				</style>
				</head>
				<body>
				<div class='empty'>&nbsp;</div>
				<table id='table' cellspacing='0' cellpadding='0'>
				<tr>
				<td class='noback' colspan='2'><div class='title'>Career Form Confirmation</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>First Name</div></td>
				<td class='td2'><div class='data'>$firstname</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Last Name</div></td>
				<td class='td2'><div class='data'> $lastname &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Date of Birth</div></td>
				<td class='td2'><div class='data'>$dateofbirth &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Email</div></td>
				<td class='td2'><div class='data'>$email &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Message</div></td>
				<td class='td2'><div class='data'>$message &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Phone</div></td>
				<td class='td2'><div class='data'>$phone &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>marital</div></td>
				<td class='td2'><div class='data'>$marital &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>experience</div></td>
				<td class='td2'><div class='data'>$experience &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>CV</div></td>
				<td class='td2'><div class='data'>Please check the attachment file &nbsp;</div></td>
				</tr>
				</table>
				<table>
				<tr style='height:25px'>
				<td class='inf2' colspan='2'>For anny enquiry  send Email :
				<a href='mailto:info@ecslebanon.com'> info@ecslebanon.com</a>
				</td>
				</tr>
				</table>
				</body>
				</html>";
			
				if($file!=''){
			//	$content = chunk_split(base64_encode(file_get_contents($_FILES["file"]["tmp_name"])));
			//	$uid = md5(uniqid(time()));		
				$typefile=array('doc','docx','pdf');
				$filetype=after('.',$_FILES['file']['name']);
				//$filesave='../uploads/CV/';
				if(!in_array($filetype,$typefile))
				{
				$result= 3;
				echo $result;
				}else if($_FILES['file']['size']>$size*1000)
					{
				$result= 5;
				echo $result;
					}else{
				//	if(!move_uploaded_file($_FILES['file']['tmp_name'],$filesave.$file))
				//	{
				//		$result='<div class="error">the file '.$file.' not Uploaded</div>';
				//	}else{
					include_once("includes/class.phpmailer.php");

				$email="hr@ecslebanon.com";
				$email1="pierre@elkhoury.me";
				$mail = new phpmailer();
				$mail->IsHTML(true); // if you are going to send HTML formatted emails
				$mail->From =  $email3;
				$mail->FromName = $firstname;
				$mail->addAddress($email,"ECS, Admin ");
				$mail->addAddress($email1,"ECS, Admin ");
				//$mail->addAddress("info@newvisionlebanon.com","New Vision, Reception");
				//$mail->addCC("user.3@ymail.com","User 3");
				//$mail->addBCC("user.4@in.com","User 4");
				$mail->Subject = "Career Form Confirmation";
				//$file_to_attach=$_FILES['file'];
				$mail->AddAttachment( $_FILES['file']['tmp_name'],$_FILES['file']['name']);
				$mail->Body = $msg;
				
				if(!$mail->Send())
					$result= "<div class='error_sub'>Message was not sent <br />PHP Mailer Error: " . $mail->ErrorInfo."</div>";
				else
					$result= 1;
				echo $result;
					}
				//	}
			}
			}
			
	



function after ($this, $inthat)
    {
        if (!is_bool(strpos($inthat, $this)))
        return substr($inthat, strpos($inthat,$this)+strlen($this));
    };
?>