-- phpMyAdmin SQL Dump
-- version 2.11.9.4
-- http://www.phpmyadmin.net
--
-- Host: 172.16.208.42
-- Generation Time: Jul 29, 2016 at 12:15 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `browsem_prod37`
--

-- --------------------------------------------------------

--
-- Table structure for table `pages_photos`
--

CREATE TABLE `pages_photos` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `pages_photos`
--

INSERT INTO `pages_photos` (`id`, `title`, `content`, `image`, `status`) VALUES
(1, 'home', '<p>Expert care services is a premier nurse and caregiver placement agency in Beirut.</p>\r\n\r\n<p>At Expert Care services we offer nurses and professional companions providing home care services on a temporary or permanent basis for all your childcare and senior care needs.</p>\r\n\r\n<p>If you are seeking to hire a nanny for your children or a companion for your loved one we can assist you in finding the care you need.</p>\r\n\r\n<p>&nbsp;</p>\r\n', '7327home.jpg', 1),
(2, 'babycare', '<p>Expert care services will provide you with a highly skilled professional who is trained and thoroughly knowledgeable in the highest quality of care.</p>\r\n\r\n<p>The baby nurse will take special care of your baby from birth to toddler including scheduling, feeding, diapering, bathing and&nbsp;maintaining the baby&#39;s room.</p>\r\n\r\n<p>Our primary goal is to ensure that the transition to parenthood is a special and memorable experience.</p>\r\n\r\n<p>Our services include placing nurses or babysitters for 24 hours care, 12 hours and 8 hours overnight or daytime care.</p>\r\n', '3377babycare.jpg', 1),
(3, 'seniorcare', '<p>Expert Care Services is committed to the highest quality of senior health care services.</p>\r\n\r\n<p>Our experienced nurses can provide assistance for seniors to maintain their sense of independence and dignity while enjoying all the comforting means at home.</p>\r\n\r\n<p>We provide peace of mind and security.Expert care services can help with compassionate, senior home care services delivered right in your loved one&#39;s home.</p>\r\n\r\n<p>Whether a few hours a day or long-term care 24 hours a day, a nurse can assist you.</p>\r\n\r\n<p>All our caregivers are thoroughly screened, extensively trained, matched to your preferences, professional and reliable.</p>\r\n', '1433seniorcare.jpg', 1),
(4, 'medicalcare', '<p>Our compassionate and caring nurses possess excellent clinical skills enabling them to effectively monitor sudden changes in a patient&#39;s condition.</p>\r\n\r\n<p>Early recognition allows for early intervention thus significantly improving patient outcomes. Some Areas of nursing we support are:</p>\r\n<a style="line-height:5px;">\r\n<p>Cardio-Pulmonary Support</p>\r\n\r\n<p>Diabetes Management</p>\r\n\r\n<p>Medication Management</p>\r\n\r\n<p>Pediatric Care</p>\r\n\r\n<p>Post Surgical Support &amp; Recovery</p>\r\n\r\n<p>Wound Care Management</p>\r\n</a>', '6225medicalcare.jpg', 1),
(5, 'babysitting', '<p>Our babysitters are professional child carers with relevant training and experience, and include nursery staff and nannies.</p>\r\n\r\n<p>We tailor our services to meet your needs and provide high caliber nannies who support family lifestyles and values through delivering the very best care to your children focusing on their well-being, happiness, educational and social development.</p>\r\n\r\n<p>Our babysitters are able to care for children of any age, from newborn through to school age children.</p>\r\n', '983babysitting.jpg', 1),
(6, 'careers', '', '5007career.jpg', 1),
(7, 'contactus', '<p>Beirut-Lebanon</p>\r\n\r\n<p>Down Town, Uruguay Street 50 ,</p>\r\n\r\n<p>Makassed center-3rd floor</p>\r\n\r\n<p>T: +961 1 990130</p>\r\n\r\n<p>M:+961 76 404023</p>\r\n\r\n<p>Email: <a href="mailto:info@ecslebanon.com?" style="text-decoration:none; color:#000;">info@ecslebanon.com </a></p>\r\n\r\n<p>Opening Hours: Monday - Friday, 9 a.m. - 5 p.m.</p>\r\n', '07222016115636.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `control` varchar(50) NOT NULL,
  `email` varchar(25) NOT NULL,
  `confirmcode` varchar(20) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `created` date NOT NULL,
  `updated` date NOT NULL,
  `fax` varchar(16) NOT NULL,
  `mobile` varchar(16) NOT NULL,
  `country` varchar(50) NOT NULL,
  `gender` varchar(2) NOT NULL,
  `company` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `status`, `control`, `email`, `confirmcode`, `phone`, `created`, `updated`, `fax`, `mobile`, `country`, `gender`, `company`) VALUES
(5, 'admin', 'admin', 'a1e480f59035561115e125d704af74ac', '1', 'Superadmin', 'admin@browse-me.net', 'yes', '', '2016-06-08', '0000-00-00', '', '', '', '', '');
