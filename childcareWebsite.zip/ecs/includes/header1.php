
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<style>


	@font-face
	{
    font-family: Myriad Pro;
    src: url(fonts/MYRIADPRO-REGULAR.OTF);
    }

html {
	font-family:"Myriad Pro";
  background: #fff;
}

body { overflow-x:hidden}

nav { width: 100%; }

.nav_wrapper {
  position: relative;
    left: -8px;
    top: -8px;
    width: 102%;
	height: ;
  transition: top .5s ease-out;
  background: #7b7b7b;
}

.scroll { top: -90px; }

.no-scroll {
  top: 0;
  z-index: 9999;
}

.btn {
  padding: 10px 1%;
  margin: 5px;
  color: #fff;
  text-decoration: none;
  font-family: sans-serif;
  transition: all 0.1s ease;
}

.btn:hover { transition: all 0.1s ease; }

main {
  max-width: 800px;
  margin: 0 auto;
}

main p {  1.2em;
}

#search {
  float: right;
  font-size: 30px;
  padding: 2px 15px;
  line-height: 40px;
  color: #fff;
  margin: 0;
  font-weight: 700;
  -webkit-transform: rotate(181deg);
  -moz-transform: rotate(181deg);
  -ms-transform: rotate(181deg);
  -o-transform: rotate(181deg);
  transform: rotate(181deg);
}

#search:hover { color: #efa666; }

.search_box {
  clear: both;
  width: 100%;
  background: #e8ebf0;
  padding: 0;
  margin: 0;
  height: 0;
  overflow: hidden;
  transition: all 0.1s ease-in-out;
}

.search_box.active {
  height: auto;
  padding: 15px 0;
}

.search_box input {
  width: 80%;
  font-size: 13px;
  margin: 0 0 0 15px;
  padding: 10px;
  border: none;
  background: #fff;
}

.search_box input:focus { outline: none; }

.search_box input.search_icon {
  clear: both;
  width: 10%;
  height: auto;
  padding: 10px;
  margin: 0;
  margin-left: -5px;
  border: none;
  color: #fff;
  cursor: pointer;
  background: #8c949d;
  opacity: 1;
  transition: all 0.1s ease;
}

.search_box input.search_icon:hover { background: #efa666; }

.menu-link { display: none; }

.spinner-master input[type=checkbox] { display: none; }

.menu {
  width: 100%;
  height: 44px !important;

  background: #7b7b7b;
  transition: all 0.3s ease;
}

.menu ul {
  padding: 0px;
  margin: 0px;
  list-style: none;
  position: relative;
  display: inline-block;
  margin-left:0px;
}

.menu > li > ul.sub_menu {
  padding: 4px 0;
  background-color: #7b7b7b;
  border: 1px solid #fff;
}

.menu ul li { padding: 0px; width:auto !important; }

.menu > ul > li { display: inline-block; }

.menu ul li a {
  display: block;
  text-decoration: none;
  color: #fff;
  font-size: 14px;
}

.menu ul li a:hover {
  background: #7b7b7b;
  color: #fff;
}

.menu ul li.hover > a {
  background: #7b7b7b;
  color: #fff;
}

.menu ul li > a { padding: 15px;  border-bottom: 1px solid #5c5555;}

.menu ul ul {
  display: none;
  position: absolute;
  top: 100%;
  min-width: 160px;
  background: #7b7b7b;
}

.menu ul li:hover > ul { display: block; }

.menu ul ul > li { position: relative; }
.menu ul ul > li a {
  padding: 10px 15px;
  height: auto;
  background: #7b7b7b;
}

.menu ul ul > li a:hover {
  background: #7b7b7b;
  color: #fff;
}

.menu ul ul ul {
  position: absolute;
  left: 100%;
  top: 0;
}

#hero {
  width: 100%;
  height: auto;
  background: #7b7b7b;
  margin: 70px 0 20px 0;
}

#hero img {
  width: 100%;
  height: auto;
}

footer {
  width: 100%;
  background: #7b7b7b;
  padding: 10px;
  color: #fff;
  margin-top: 40px;
}

footer a {
  color: #fff;
  text-decoration: none;
}
.logo{}


.menu ul li a{height:16px;}





.menubar_babycare:hover{ border-bottom:4px solid #fff;}
.menubar_babycare_active{ border-bottom:4px solid #fff; }
 
.menubar_seniorcare:hover{ border-bottom:4px solid #fff;}
.menubar_seniorcare_active{ border-bottom:4px solid #fff;}

.menubar_medicalcare:hover{ border-bottom:4px solid #fff;}
.menubar_medicalcare_active{ border-bottom:4px solid #fff;}

.menubar_babysitting:hover{ border-bottom:4px solid #fff;}
.menubar_babysitting_active{ border-bottom:4px solid #fff;}

.menubar_careers:hover{ border-bottom:4px solid #fff;}
.menubar_careers_active{ border-bottom:4px solid #fff;}

.menubar_contactus:hover{ border-bottom:4px solid #fff;}
.menubar_contactus_active{ border-bottom:4px solid #fff; }


@media all and (min-width: 1400px) and (max-width: 1600px) {
.menu > ul > li {margin-left:20px;}
.menu ul li > a {border-bottom:none; }
.menu ul {left:10%;}
.logo{margin-left:111px; margin-top: 4px;}
.menu ul li a{ font-size:18px; margin-bottom:-8px;      margin-top: -4px;}

}


@media all and (min-width: 1024px) and (max-width: 1400px) {

.menu ul {left:10%;}
.logo{margin-left:111px; margin-top: 4px;}
.menu ul li a{ font-size:18px;}
.menu ul li > a {border-bottom:none; }
.menu ul li a{ font-size:18px; margin-bottom:-8px; margin-top: -4px;}
.logo{margin-left:px; margin-top:4px;}



}




@media all and (min-width: 767px) and (max-width: 1024px) {
.menu ul li a{ font-size:18px; margin-bottom:-8px; margin-top: -4px;}
.logo{ margin-top:4px;}

.menu ul li > a {border-bottom:none; }
}

 @media all and (max-width: 766px) {
	 .nav_wrapper { height: !important;}
	 
.menubar_babycare:hover{ border-bottom:0px solid #fff;}
.menubar_babycare_active{ border-bottom:0px solid #fff; }
 
.menubar_seniorcare:hover{ border-bottom:0px solid #fff;}
.menubar_seniorcare_active{ border-bottom:0px solid #fff;}

.menubar_medicalcare:hover{ border-bottom:0px solid #fff;}
.menubar_medicalcare_active{ border-bottom:0px solid #fff;}

.menubar_babysitting:hover{ border-bottom:0px solid #fff;}
.menubar_babysitting_active{ border-bottom:0px solid #fff;}

.menubar_careers:hover{ border-bottom:0px solid #fff;}
.menubar_careers_active{ border-bottom:0px solid #fff;}

.menubar_contactus:hover{ border-bottom:0px solid #fff;}
.menubar_contactus_active{ border-bottom:0px solid #fff; }



.example-header .container { width: 100%; }

#search { padding: 10px; }

.spinner-master * {
  transition: all 0.3s;
  box-sizing: border-box;
}

.spinner-master {
  position: relative;
  margin: 5px;
  height: 30px;
  width: 30px;
  float: left;
    top:13px;
}

.spinner-master label {
  cursor: pointer;
  position: absolute;
  z-index: 99;
  height: 100%;
  width: 100%;
  top: -5px;
  left: 5px;
}

.spinner-master .spinner {
  position: absolute;
  height: 2px;
  width: 67%;
  padding: 0;
  background-color: #fff;
}

.spinner-master .diagonal.part-1 {
  position: relative;
  float: left;
}

.spinner-master .horizontal {
  position: relative;
  float: left;
  margin-top: 4px;
}

.spinner-master .diagonal.part-2 {
  position: relative;
  float: left;
  margin-top: 4px;
}

.spinner-master input[type=checkbox]:checked ~ .spinner-spin > .horizontal { opacity: 0; }

.spinner-master input[type=checkbox]:checked ~ .spinner-spin > .diagonal.part-1 {
  transform: rotate(135deg);
  -webkit-transform: rotate(135deg);
  margin-top: 10px;
}

.spinner-master input[type=checkbox]:checked ~ .spinner-spin > .diagonal.part-2 {
  transform: rotate(-135deg);
  -webkit-transform: rotate(-135deg);
  margin-top: -8px;
}

a.menu-link {
  display: block;
  color: #fff;
  float: left;
  text-decoration: none;
  padding: 10px 16px;
  font-size: 1.5em;
}

a.menu-link:hover { color: #7b7b7b; }

a.menu-link:after {
  content: "\2630";
  font-weight: normal;
}

a.menu-link.active:after { content: "\2715"; }

.menu {
  clear: both;
  min-width: inherit;
  float: none;
    height:800px !important;

}

.menu,
.menu > ul ul {
  overflow: hidden;
  max-height: 0;
  background-color: #7b7b7b;
}

.menu > li > ul.sub-menu {
  padding: 0px;
  border: none;
}

.menu.active,
.menu > ul ul.active { max-height: 55em; }

.menu ul { display: inline; }



.menu li,
.menu > ul > li { display: block; }

.menu > ul > li:last-of-type a { border: none; }

.menu li a {
  color: #fff;
  display: block;
  padding: 0.8em;
  position: relative;
}

.menu li.has-submenu > a:after {
  content: '+';
  position: absolute;
  top: 0;
  right: 0;
  display: block;
  font-size: 1.5em;
  padding: 0.55em 0.5em;
}

.menu li.has-submenu > a.active:after { content: "-"; }

.menu ul ul > li a {
  background-color: #7b7b7b;
  padding: 10px 18px 10px 30px;
}

.menu ul li a:hover {
  background: #red;
  color: #fff;
}

.menu ul li.hover > a {
  background: #7b7b7b;
  color: #fff;
}

.menu ul ul,
.menu ul ul ul {
  display: inherit;
  position: relative;
  left: auto;
  top: auto;
  border: none;
}

.search_box {
  position: absolute;
  top: 60px;
  left: 0;
  z-index: 10;
}

.search_box input { width: 70%; }

.search_box input.search_icon { width: 17%; }

#hero { height: 200px; }

}
</style>
</head>

<body>
<div class="nav_wrapper"> 
  <!--<a class="menu-link" href="#menu"></a>-->
  
  <div class="spinner-master">
    <input type="checkbox" id="spinner-form" />
    <label for="spinner-form" class="spinner-spin">
    <div class="spinner diagonal part-1"></div>
    <div class="spinner horizontal"></div>
    <div class="spinner diagonal part-2"></div>
    </label>
  </div>
  <a href="home.php"><div class="logo"></div></a>
  <nav id="menu" class="menu">
    <ul class="dropdown">
      <li class="menubar_babycare"  id="babycare_id"><a  class="menubar_babycare_txt" href="babycare.php" title="Baby care">Baby care</a>
      </li>
      <li class="menubar_seniorcare"  id="seniorcare_id"><a class="menubar_seniorcare_txt" href="seniorcare.php" title="Senior care">Senior care</a>
      </li>
      <li  class="menubar_medicalcare" id="medicalcare_id"><a  class="menubar_medicalcare_txt"href="medicalcare.php" title="Medical care">Medical care</a>
      </li>
      <li  class="menubar_babysitting" id="babysitting_id"><a class="menubar_babysitting_txt" href="babysitting.php" title="Babysitting">Babysitting</a>
      </li>
      <li  class="menubar_careers" id="careers_id"><a class="menubar_careers_txt" href="careers.php" title="Careers">Careers</a>
      </li>
      <li  class="menubar_contactus" id="contactus_id"><a class="menubar_contactus_txt" href="contact.php" title="Contact us">Contact us</a></li>
    </ul>
  </nav>
  <form class="search_box" id="search_box" action="/search/">
    <input name="search_criteria" placeholder="Search here" value="" type="text">
    <input class="search_icon" value="Search" type="submit">
  </form>
</div>

  
  



  
  
  
  

<script src="http://code.jquery.com/jquery-2.1.3.min.js"></script> 
<script>
$('ul li:has(ul)').addClass('has-submenu');
$('ul li ul').addClass('sub-menu');
$('ul.dropdown li').hover(function () {
    $(this).addClass('hover');
}, function () {
    $(this).removeClass('hover');
});
var $menu = $('#menu'), $menulink = $('#spinner-form'), $search = $('#search'), $search_box = $('.search_box'), $menuTrigger = $('.has-submenu > a');
$menulink.click(function (e) {
    $menulink.toggleClass('active');
    $menu.toggleClass('active');
    if ($search.hasClass('active')) {
        $('.menu.active').css('padding-top', '50px');
    }
});
$search.click(function (e) {
    e.preventDefault();
    $search_box.toggleClass('active');
});
$menuTrigger.click(function (e) {
    e.preventDefault();
    var t = $(this);
    t.toggleClass('active').next('ul').toggleClass('active');
});
$('ul li:has(ul)');
$(function () {
    var e = $(document).scrollTop();
    var t = $('.nav_wrapper').outerHeight();
    $(window).scroll(function () {
        var n = $(document).scrollTop();
        if ($(document).scrollTop() >= 50) {
            $('.nav_wrapper').css('position', 'relative');
        } else {
            $('.nav_wrapper').css('position', 'relative');
        }
        if (n > t) {
            $('.nav_wrapper').addClass('scroll');
        } else {
            $('.nav_wrapper').removeClass('scroll');
        }
        if (n > e) {
            $('.nav_wrapper').removeClass('no-scroll');
        } else {
            $('.nav_wrapper').addClass('no-scroll');
        }
        e = $(document).scrollTop();
    });
});
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
  
<script>
$(document).ready( function(){

var page='<?=$_SESSION['ecs_page']?>';

switch (page){
	case 'babycare_id':{
		$("#"+page).addClass("menubar_babycare_active")
		break;
	}
	case 'seniorcare_id':{
		$("#"+page).addClass("menubar_seniorcare_active")
		break;
	}
	case 'medicalcare_id':{
		$("#"+page).addClass("menubar_medicalcare_active")
		break;
	}
	case 'babysitting_id':{
		$("#"+page).addClass("menubar_babysitting_active")
		break;
	}
	case 'careers_id':{
		$("#"+page).addClass("menubar_careers_active")
		break;
	}
	case 'contactus_id':{
		$("#"+page).addClass("menubar_contactus_active")
		break;
	}
		
		
}
})
</script>
