

function fn_careers()
{

				var firstname=$("#firstname_id").val();
				var lastname=$("#lastname_id").val();
				var dateofbirth=$("#dateofbirth_id").val();
				var email=$("#email_id").val();
                var message=$("#message_id").val();
				var phone=$("#phone_id").val();
				var marital=$("#marital_id").val();
				var experience=$("#experience_id").val();
				var browse=$("#browse_id").val();
				var value=false;
				
			if(firstname <=0 || !isNaN(firstname)){$("#firstname_id").css({"border":"1px solid #e52338"});value=false;}
				else{$("#firstname_id").css({"border":"1px solid #7b7b7b"});value=true;}

			if(isNaN(phone)||phone==''){$("#phone_id").css({"border":"1px solid #e52338"});value=false;}
				else{$("#phone_id").css({"border":"1px solid #7b7b7b"});value=true;}
				
			if(browse <=0 || browse == ""){$("#browse_id").css({"border":"1px solid #e52338"});value=false;}
			else{$("#firstname_id").css({"border":"1px solid #7b7b7b"});value=true;}
			
			var broval= browse.split('.').pop();
			
			if(broval=='doc' || broval=='pdf'){
			if(value==true ){
				
			 var	data=  new FormData(document.querySelector("#form_career"));
		$.ajax({	
					url:'sendemail_career.php',
					type:'post',
					data:data,
					contentType: false,
		            processData:false,
					success:function(re){
						if(re==1){
						var boton = "button";
						
						swal({   
						title: "Your form has been sent successfully!",  
						html: true ,
						confirmButtonColor: '#7b7b7b'
						});
						
						$('#firstname_id').val('');
						$('#lastname_id').val('');
		                $('#dateofbirth_id').val('');
						$('#email_id').val('');
						$('#message_id').val('');
						$('#phone_id').val('');
						$('#marital_id').val('');
						$('#experience_id').val('');
						$('#browse_id').val('');
						}
						
						
					
						
						else if(re==5){
						var boton = "button";
						
						swal({   
						title: "Maximum file size 1MB !",  
						html: true ,
						confirmButtonColor: '#7b7b7b'
						});
						}
						
						
						else{alert (re)}
			
					},
					error:function(e){alert(e)}
				});
			}
		}else {
				var boton = "button";
						
						swal({   
						title: "This file type is not allowed!",  
						html: true ,
						confirmButtonColor: '#7b7b7b'
						});
				
				
				}
					
	}  
		


function validateEmail(email) {var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;if (filter.test(email)){return true;}else {return false;}}
