<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/css.css">

<link href="assets/lib/sweetalert.min.css" rel="stylesheet" />
<script src="assets/lib/sweetalert.min.js"></script>
<script src="assets/lib/jquery-1.11.3.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
 <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo.png" />

<title>Expert Care services - ECS - Nurse - Babysitter - Child Care - Senior Care - Beirut - Lebanon</title>
<meta name="description" content="Expert Care services - ECS - Specialises in Nursing - Childcare - Baby Nurse - Babysitter - Homecare - Nanny - Beirut - Lebanon" /> 
<meta name="keywords" content="ECS, expert care services, nurse, babysitter, nanny, nursing, babysitting, beirut, lebanon, childcare, expert, care, services, amer, zein, lama, nurse, babysitter, baby, kids" />
<script type="text/javascript" src="includes/js.js"></script>
<?php 

$_SESSION['ecs_page']='careers_id';
?>
</head>





<body class="background_ecs">
<?php include "includes/header1.php"; ?>

		  <?php
		 include 'db/db.php';
		 $sql_pages_photos="select * from pages_photos where title = 'careers'";
		 $res_pages_photos=mysql_query($sql_pages_photos);
		 $result_pages_photos=mysql_fetch_array($res_pages_photos);
		  ?>

<div class="content2">
<div class="text1">
<div class="title2">Careers</div>
<div class="pagaghraph2">





<form id="form_career" class="alignment_career" name="form_career" method="post"  action="javascript:void(0)">

<div class="firstname_position"><a class="title_sty" style="color:#7b7b7b; font-size:16px; font-family:"AddFont"; font-family:"MS Sans Serif";">First Name:</a>
<div class="boxes_al"><input class="firstname_contactus" type="text" name="firstname_id" id="firstname_id"  style="color:#000000;  border:1px solid #7b7b7b; font-size:20px; font-family: AddFont; font-family:'Times New Roman', Times, serif !important; " /></div>
</div>
<div class="lastname_position"><a class="title_sty" style="color:#7b7b7b; font-size:16px; font-family:"AddFont"; font-family:"MS Sans Serif";">Last Name:</a>
<div class="boxes_al"><input class="lastname_contactus" type="text" name="lastname_id"  id="lastname_id"  style="color:#000000;  border:1px solid #7b7b7b; font-size:20px; font-family: AddFont; font-family:'Times New Roman', Times, serif !important; " /></div>
</div>
<div class="dateofbirth_position"><a class="title_sty" style="color:#7b7b7b; font-size:16px; font-family:"AddFont"; font-family:"MS Sans Serif";">Date of Birth:</a>
<div class="boxes_al"><input class="dateofbirth_contactus" type="text" name="dateofbirth_id" id="dateofbirth_id"  style="color:#000000;  border:1px solid #7b7b7b; font-size:20px; font-family: AddFont; font-family:'Times New Roman', Times, serif !important; "/></div>
</div> 
<div class="email_position"><a class="title_sty" style="color:#7b7b7b; font-size:16px; font-family:"AddFont"; font-family:"MS Sans Serif";">Email:</a>
<div class="boxes_al"><input class="email_contactus" type="text" name="email_id" id="email_id"  style="color:#000000;  border:1px solid #7b7b7b; font-size:20px; font-family: AddFont; font-family:'Times New Roman', Times, serif !important; "/></div>
</div>

<div class="message_position"> <a class="title_sty" style="color:#7b7b7b; font-size:16px;  font-family:"AddFont"; font-family:"MS Sans Serif";">Write your Message:</a>
<div class="boxes_al"><textarea class="message_contactus" maxlength="160"  style="overflow:auto; resize:none; color:#000000;  border:1px solid #7b7b7b; font-size:20px; font-family: AddFont; font-family:'Times New Roman', Times, serif !important;" rows="6" cols="50"  name="message_id" id="message_id"/></textarea></div> 
</div>
<div class="phone_number_position"><a class="title_sty" style="color:#7b7b7b; font-size:16px;  font-family:"AddFont"; font-family:"MS Sans Serif";">Phone Number:</a>
<div class="boxes_al"><input class="phone_contactus" type="text" name="phone_id" id="phone_id"  style="color:#000000;  border:1px solid #7b7b7b; font-size:20px; font-family: AddFont; font-family:'Times New Roman', Times, serif !important; "/></div>
</div> 
<div class="marital_status_position"><a class="reg_sty" style="color:#7b7b7b; font-size:16px;  font-family:"AddFont"; font-family:"MS Sans Serif";">Marital Status:</a>
<div class="new_a1r">
<div class="boxes_al"><select class="marital_status_contactus" name="marital_id" id="marital_id"  style="color:#000000;  cursor:pointer;  border:1px solid #7b7b7b; direction:ltr; font-size:12px; font-family: AddFont; font-family:"MS Sans Serif"; "/></div>
<option style="background-color:#7b7b7b; color:#fff;" value=""><span  color:#ffffff;></span></option>
				<option style="background-color:#9a9a9a; color:#fff;" value="single">Single</option>
				<option style="background-color:#9a9a9a; color:#fff;" value="married">Married</option>
				<option style="background-color:#9a9a9a; color:#fff;" value="divorced">Divorced</option>
				<option style="background-color:#9a9a9a; color:#fff;" value="widowed">Widowed</option></select></div></div> 
<div class="years_of_Experience_position"><a class="title_sty" style="color:#7b7b7b; font-size:16px;  font-family:"AddFont"; font-family:"MS Sans Serif";">Years of Experience:</a>
<div class="boxes_al"><input class="years_of_Experience_contactus" type="text" name="experience_id" id="experience_id"  style="color:#000000;  border:1px solid #7b7b7b; font-size:12px; font-family: AddFont; font-family:'Times New Roman', Times, serif !important; " /></div>
</div>
<div class="browse_position"><a class="title_sty" style="color:#7b7b7b; font-size:16px;  font-family:"AddFont"; font-family:Myriad Pro;">Upload your CV:</a>
<div class="boxes_al"><input class="browse_contactus" type="text" name="browse_id"  id="browse_id" onclick="document.getElementById('browse_id').readOnly = true;"  style="color:#000000;  border:1px solid #7b7b7b; font-size:12px; font-family: AddFont; font-family:'MS Sans Serif' !important; " /><div class="file_browse">
<input class="browse_st"  value="Browse..." id="file" name="file" type="file"  onchange="document.getElementById('browse_id').value = this.value; "></div></div>
</div>




<div class="submitbox_position">
<input class="submit_style" style="cursor:pointer; color:#7b7b7b; border: 1px solid #7b7b7b; font-size:16px; height: 36px; font-family: AddFont; font-family:'MS Sans Serif';  "   type="submit" name="send_id" id="send_id" value="Send" onclick="fn_careers()" />
</div>

</form> 



</div>
</div>
<div class="image1">
<img src="uploads/<?=$result_pages_photos['image']?>" alt="<?=$result_pages_photos['image']?>" width="100%" height="100%"/>
</div>
</div>
<div class="tail"></div>
</body>
</html>