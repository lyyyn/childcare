<?php
require_once('../../db/db.php');
if($_POST['delete'])
	{
		$checkbox = $_POST['checkbox'];
		$countCheck = count($_POST['checkbox']);
		for($i=0;$i<$countCheck;$i++)
		{               $del_id  = $checkbox[$i];
						

			$q1 = mysql_query("DELETE from users where id = $del_id");
			
		}
		header("Location: ../users.php");
	}
?>