<div id="main-content">
   <div id="indicator"><strong>Logged in as : <?php echo $fgmembersite->UserFullName(); ?></strong>  </div>
 <div id="left-menu">
	   <?php include('includes/leftmenu.php'); ?>
 </div>
 <div id="pagecontent">
  <div id="content-left">
   <?php include('../db/db.php'); ?>
   <div class="top_link">
   <div class="left_link">
    <a href="javascript:backpage()" class="backbutton">Back</a>
   </div>
   <div class="right_link">
  <a href="javascript:void(0)" onclick="AddNew('users/addform.php')" class="addnewform">Add New</a>
  </div>
  </div>
   <form method='post' action='users/data-delete.php' name="deleteForm" id="deleteForm">
     <div class="demo_jui" id="content_table">
          <?php include "users/table.php";?>
	 </div>
    <input id='delete' type='submit' class='button' name='delete' value='Delete Selected Items' onclick="return confirm('Do you wish to Delete Items?')"/>
   </form>
	</div>
     <div id="content-right">
	   <div id="contentAjax">
			<form action="users/add-data.php" method="post"  name="AddNew" id="AddNew"  enctype="multipart/form-data" >
			   <div id="leftform">
						 <label>Username(*)</label>
						 <input type="text" name="username" id="username" value="" class="inptext" />
						 <label>Name(*)</label>
						 <input type="text" name="name" id="name" value="" class="inptext" />
						 <label>Email(*)</label>
						 <input type="text" name="email" id="email" value="" class="inptext" />
						 <label>Password(*)</label>
						 <input type="text" name="password" id="password" value="" class="inptext" />
						 <label>Control(*)</label>
						 <select name="control" class="inpselect">
						   <option value="Superadmin">Superadmin</option>
						   <option value="Admin">Admin</option>
						   <option value="User">User</option>
						 </select>
						 <label>Phone</label>
						 <input type="text" name="phone" id="phone" value="" class="inptext" />
						 <label>Mobile</label>
						 <input type="text" name="mobile" id="mobile" value="" class="inptext" />
			   </div>
			   <div id="bottomform">
				<input type="submit" value="Add" name="submitform" class="submitform" />
				</div>
			  </form>
		</div>
	</div>
 </div>
</div>

