<?php
function secureInput($var)
{
	$output = '';
    if (is_array($var)){
        foreach($var as $key=>$val){
            $output[$key] = secureInput($val);
        }
    } else {
		$var = strip_tags(trim($var));
		if (function_exists("get_magic_quotes_gpc")) {
			$output = mysql_real_escape_string(get_magic_quotes_gpc() ? stripslashes($var) : $var);
		} else {
			$output = mysql_real_escape_string($var);
		}
	}
	if (!empty($output))
	return $output;
}
?>