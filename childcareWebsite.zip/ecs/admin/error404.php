<?PHP
session_start();
require_once('../db/db.php');
require_once("include/membersite_config.php");
if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("index.php");
    exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Options | BACKEND | Error404</title>
<?php require_once('includes/head.php'); ?>
<?php require_once('includes/css.php'); ?>
<?php require_once('includes/js.php'); ?>
</head>
<body>
<?php
require_once('includes/header.php');
?>
<?php
require_once('includes/404.php');
?>
<?php
require_once("includes/footer.php"); 
?>
</body>
</html>