<?php
include('../../db/db.php');
include ('../includes/thumb.php');
include '../secureInput.php';
if (isset ($_POST['submitform'])) {
	$title=secureInput($_POST['title']);
	$content=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['content']);
	$status=secureInput($_POST['status']);
	
	
	//secureInput($_POST['page_s']);
	$file=$_FILES['file']['name'];
	if($title=='' or $status=='' or $file=='')
	echo '<div class="error">Please insert all the required field (*)</div>';
	else{
		$typefile=array('jpg','png','jpeg');
		$maxsize=1000;
		$maxwidth=800;
		$filesize=$_FILES['file']['size'];
		$filetype=after('.',$_FILES['file']['name']);
		$filesave='../../uploads/';
		$data = mysql_real_escape_string($_FILES['file']['tmp_name']);
		$size1 = getimagesize($data);
					$width = $size1[0];
					$height = $size1[1];
		if($filesize>$maxsize*1000)
		{
			$result='<div class="error">the size of '.$file.' less 800 kb</div>';
		}else{
			if(!in_array($filetype,$typefile))
			{
				$result='<div class="error">the type of '.$filetype.' not specified in List</div>';
			}else{
				$filename=date("mdYHis").".".$filetype;
				$filetumb='../../uploads/thumb/'.$filename;
				if(!move_uploaded_file($_FILES['file']['tmp_name'],$filesave.$filename))
				{
					$result='<div class="error">the file '.$filename.' not Uploaded</div>';
				}else{
				
				makeThumbnails($width,$height,$maxwidth,$filesave.$filename,$filetumb);
		$q6=mysql_query("insert into  pages_photos (title,status,image, content) values('$title','$status','$filename' ,'$content')") or die(mysql_error());
		echo'<div class="success">Content was added successfully.</div>';
				}
			}
		}
	}
	
 }
?>