	<div id="preview"></div>
	<form action="pages_photos/add-slider.php" method="post"  name="AddNew" id="AddNew"  enctype="multipart/form-data" >
				   <div id="leftform">
	            <div id="preview"></div>
					
                    
                         <label>Title</label>
					         <select name="title" class="inpselect">
							 <option value=""><?=$rr['title']?></option>
							 <option value="home">Home Photo</option>
                             <option value="babycare">Baby Care Photo</option>
                             <option value="seniorcare">Senior Care Photo</option>
							 <option value="medicalcare">Medical Care Photo</option>
                             <option value="babysitting">Baby Sitting Photo</option>
                             <option value="careers">Careers Photo</option>
							 <option value="contactus">Contact Us Photo</option>
                         </select>
					  
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="">Select your status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
						 
                      <label>Content</label><textarea name="content" id="content" class="txtarea"></textarea>

                         
						 
						 

				   </div>
				   <div id="bottomform">
					
				<input type="submit" value="Add" name="submitform" class="submitform" />
                <input type="reset" value="reset" id="reset" />
				   </div>
			</form>
