<?PHP
/*require_once("include/fg_membersite.php");
$fgmembersite = new FGMembersite();
$fgmembersite->SetWebsiteName('www.yellowrosa.com');
$fgmembersite->SetAdminEmail('info@yellowrosa.com');
$fgmembersite->InitDB('mysql05.newlebhost.com',
                      'yellowr_user',
                      'P1@ssw0rD3',
                      'yellowr_db',
                      'users');
$fgmembersite->SetRandomKey('qSRcVS6DrTzrPvr');*/
?>
<?PHP
require_once("include/fg_membersite.php");
$fgmembersite = new FGMembersite();
$fgmembersite->SetWebsiteName('www.browse-me.com');
$fgmembersite->SetAdminEmail('info@browse-me.com');
$fgmembersite->InitDB(/*hostname*/'localhost',
                      /*username*/'root',
                      /*password*/'',
                      /*database name*/'ecs',
                      /*table name*/'users');
/**
hostname'mysql02.newlebhost.com',
username'browsem_prod',
password'Browse_Me_13',
database name'browsem_prod1',
table name'users'
**/
$fgmembersite->SetRandomKey('qSRcVS6DrTzrPvr');
?>