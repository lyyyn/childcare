<?PHP
session_start();
require_once('../db/db.php');
require_once("include/membersite_config.php");
if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("index.php");
    exit;
}
?>

<meta http-equiv="cache-control" content="no-cache,no-store,must-revalidate">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<link rel="stylesheet" type="text/css" href="assets/css/reset.css" />
<link rel="stylesheet" type="text/css" href="assets/css/styles.css" />

<link rel="stylesheet" href="assets/css/jquery.dataTables.css" type="text/css" />

<link rel="stylesheet" type="text/css" href="assets/css/jquery.datepick.css" />
<link rel="stylesheet" type="text/css" href="assets/css/fancybox.css" />


<script type="text/javascript" src="assets/js/jquery-1.8.3.min.js"></script>
<script type='text/javascript' src='assets/js/jquery.plugin.js'></script>
<script type='text/javascript' src='assets/js/jquery.datepick.js'></script>
<script src="//cdn.ckeditor.com/4.4.6/full/ckeditor.js"></script>
<script type="text/javascript" language="javascript" src="assets/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="assets/js/ajax.js"></script>
<script type='text/javascript' src='assets/js/jquery.form.js'></script>
<script src="assets/js/fancybox.js" language="javascript"></script>