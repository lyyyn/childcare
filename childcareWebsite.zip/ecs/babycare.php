<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/css.css">
 <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo.png" />
<title>Expert Care services - ECS - Nurse - Babysitter - Child Care - Senior Care - Beirut - Lebanon</title>
<meta name="description" content="Expert Care services - ECS - Specialises in Nursing - Childcare - Baby Nurse - Babysitter - Homecare - Nanny - Beirut - Lebanon" /> 
<meta name="keywords" content="ECS, expert care services, nurse, babysitter, nanny, nursing, babysitting, beirut, lebanon, childcare, expert, care, services, amer, zein, lama, nurse, babysitter, baby, kids" />

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<?php 
session_start();
$_SESSION['ecs_page']='babycare_id';
?>
</head>




<body class="background_ecs">
<?php include "includes/header1.php"; ?>

		  <?php
		 include 'db/db.php';
		 $sql_pages_photos="select * from pages_photos where title = 'babycare'";
		 $res_pages_photos=mysql_query($sql_pages_photos);
		 $result_pages_photos=mysql_fetch_array($res_pages_photos);
		  ?>

<div class="content1">
<div class="text">
<div class="title">Baby Care</div>
<div class="pagaghraph"><?=$result_pages_photos['content']?></div>
</div>
<div class="image">
<img src="uploads/<?=$result_pages_photos['image']?>" alt="<?=$result_pages_photos['image']?>" width="100%" height="100%" />
</div>
</div>
<div class="tail"></div>
</body>
</html>